# Contrôle de livraison — 17 octobre 2026

Contrôles effectués sur le site servi localement, dans le navigateur intégré. La version livrée reste une démonstration ; aucune publication distante n’a été effectuée.

## Formats et présentation

| Viewport testé | Débordement horizontal du document |
| --- | --- |
| 320 × 740 | Aucun |
| 390 × 844 | Aucun |
| 568 × 320, paysage | Aucun |
| 768 × 1 024 | Aucun |
| 1 024 × 768 | Aucun |
| 1 440 × 900 | Aucun |
| 1 920 × 1 080 | Aucun |

La largeur du document a été comparée à sa largeur disponible, avec la barre de défilement prise en compte. Le hero, l’atelier, la galerie et le brouillon ont également été inspectés visuellement. Les captures ordinateur et mobile accompagnent la livraison.

Défauts corrigés pendant la recette : titre mobile initialement coupé sur quatre lignes ; débordement de la présentation à 320 px ; panneau de navigation trop haut en paysage ; formulaire natif pouvant transmettre une URL sans JavaScript ; derniers libellés de coordonnées fictives dispersés.

## Interactions vérifiées

- Menu mobile : ouverture, état `aria-expanded`, fermeture par Échap, retour du focus au bouton, fermeture après sélection d’une rubrique et focus transféré à la destination.
- À 568 × 320, le menu est défilable et reste dans la hauteur disponible ; le lien Contact est accessible.
- Lien d’évitement atteint au clavier, puis transfert du focus au contenu principal.
- Les cinq cartes préparent une sélection de service ; parcours complet testé avec Diagnostic.
- Formulaire vide : préparation bloquée, focus placé sur le nom manquant, aucun brouillon et aucune navigation avec les données dans l’URL.
- Brouillon valide : accents et ponctuation conservés, service et véhicule repris, sujet et corps du lien `mailto:` encodés.
- Copie du message effectuée : le retour confirme uniquement la copie, sans annoncer d’email envoyé.
- Modification du brouillon : retour au formulaire, informations conservées et focus sur le message.
- Galerie : ouverture, photographie suivante, retour par flèche clavier, fermeture par Échap et retour du focus à l’image d’origine.
- Fenêtre de confidentialité et questions fréquentes ouvertes puis refermées.
- La barre d’action mobile s’efface lorsque la rubrique Contact est visible.

L’application de messagerie n’a pas été ouverte et aucun email n’a été envoyé. L’adresse `.example` est fictive. L’appel fictif reste protégé ; il ne possède pas de lien `tel:` actif.

## Repli et accessibilité

Une copie temporaire de la page sans ses deux scripts a été testée à 320 px : navigation visible, notice explicative affichée, zéro contrôle de formulaire activé et aucun débordement. Cette copie de contrôle a été retirée de la livraison.

Le HTML conserve les contenus, les titres et les ancres sans JavaScript. Les améliorations interactives utilisent des libellés explicites et des dialogues natifs. Les images possèdent des textes alternatifs et des dimensions. La galerie conserve un rapport d’image défini pour éviter les sauts de mise en page.

Contrastes calculés à partir des couleurs CSS, sans prétendre à un audit complet :

| Combinaison | Rapport |
| --- | ---: |
| Texte ivoire sur anthracite | 15,34:1 |
| Texte secondaire sur anthracite | 8,48:1 |
| Orange sur anthracite / texte anthracite sur orange | 6,57:1 |
| Texte des services sur ivoire | 5,59:1 |
| Surtitres sur ivoire | 5,75:1 |
| Texte indicatif des champs sur leur fond | 7,32:1 |

`prefers-reduced-motion` désactive les transitions et le défilement animé ; vérification du code effectuée. Ce contrôle ne remplace pas un essai avec lecteur d’écran, un zoom important et les réglages d’accessibilité d’appareils physiques.

## Ressources et performance

- Les 14 ressources locales référencées ont répondu HTTP 200, variantes comprises.
- 40 identifiants HTML uniques ; contrôle de 21 références/ancres sans cible manquante ni variable de modèle résiduelle.
- Syntaxe de `app.js` vérifiée avec Node.js ; génération de la page exécutée avec succès.
- Aucun avertissement ni erreur relevé dans la console du navigateur pendant les contrôles.
- Environ **625 Ko pour l’ensemble des ressources web**, variantes comprises et hors compression HTTP : ce total ne représente pas le transfert du premier écran.
- Six fichiers photographiques WebP : **508 986 octets** au total. Deux polices WOFF2 : **47 144 octets**.
- Photo principale prioritaire avec variantes adaptées ; images suivantes différées. Aucun framework, script analytique ou police externe chargé par la page.

**Lighthouse n’a pas été exécuté. Aucun score n’est annoncé.** Mesurer performance, LCP, CLS, INP, accessibilité et SEO sur l’URL finale, avec conditions mobiles et cache froid. Les temps de réponse de GitHub Pages et le comportement d’un vrai logiciel de messagerie restent à vérifier après publication.

## À finaliser pour une entreprise réelle

La liste complète figure dans le README. Les points nécessaires sont l’identité, les coordonnées, l’offre réellement proposée, les photos autorisées, l’URL SEO et les informations légales. Le mode démonstration applique `noindex` ; le retirer ne dispense pas de remplacer les contenus fictifs. Aucun système de réservation, d’envoi serveur ou de suivi commercial n’est inclus.
