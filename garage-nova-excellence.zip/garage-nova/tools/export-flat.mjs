/** Optional flat publication bundle, for hosts accepting a single file selection. */
import {readFile,writeFile,mkdir,copyFile} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
if(!process.argv[2])throw new Error('Usage: node tools/export-flat.mjs <output-directory>');
const output=path.resolve(process.argv[2]);
if(output===root)throw new Error('Choose a separate output directory.');
await mkdir(output,{recursive:true});
for(const file of ['index.html','styles.css','app.js','assets/site-config.js']){
  const content=(await readFile(path.join(root,file),'utf8')).replaceAll('assets/images/','').replaceAll('assets/fonts/','').replaceAll('assets/brand.svg','brand.svg').replaceAll('assets/favicon.svg','favicon.svg').replaceAll('assets/site-config.js','site-config.js');
  await writeFile(path.join(output,path.basename(file)),content);
}
for(const file of ['.nojekyll','robots.txt','assets/brand.svg','assets/favicon.svg','assets/fonts/barlow-condensed-latin-600.woff2','assets/fonts/manrope-latin-variable.woff2','assets/fonts/Barlow-Condensed-OFL.txt','assets/fonts/Manrope-OFL.txt','assets/fonts/SOURCES.md','assets/images/CREDITS.txt','assets/images/hero.webp','assets/images/hero-800.webp','assets/images/workshop.webp','assets/images/workshop-600.webp','assets/images/detail-wheel.webp','assets/images/detail-body.webp']){
  await copyFile(path.join(root,file),path.join(output,path.basename(file)));
}
console.log('Flat publication bundle exported. Original modular sources are unchanged.');
