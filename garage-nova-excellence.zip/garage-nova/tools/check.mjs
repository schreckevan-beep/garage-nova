/** Small, dependency-free release check for paths and generated markup. */
import {readFile,access} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const html=await readFile(path.join(root,'index.html'),'utf8');
const css=await readFile(path.join(root,'styles.css'),'utf8');
const ids=[...html.matchAll(/\bid="([^"]+)"/g)].map(match=>match[1]);
const failures=[];
if(new Set(ids).size!==ids.length) failures.push('Duplicate HTML IDs');
if(html.includes('{{')) failures.push('Unresolved template content');
if(!/<fieldset[^>]*\bdisabled/.test(html)) failures.push('Form must start disabled until JS handles submit');
const refs=new Set([...html.matchAll(/\b(?:src|href)="([^"]+)"/g)].map(match=>match[1]));
for(const match of html.matchAll(/\bsrcset="([^"]+)"/g)) match[1].split(',').forEach(part=>refs.add(part.trim().split(/\s/)[0]));
for(const match of css.matchAll(/url\(['"]?([^)'"\s]+)['"]?\)/g)) refs.add(match[1]);
for(const ref of refs){
  if(ref.startsWith('#')) {if(!ids.includes(ref.slice(1)))failures.push(`Missing anchor: ${ref}`);continue;}
  if(/^(https?:|mailto:|tel:|data:)/.test(ref))continue;
  try{await access(path.join(root,ref));}catch{failures.push(`Missing local file: ${ref}`);}
}
if(failures.length){console.error(failures.join('\n'));process.exitCode=1;}
else console.log(`Release check passed: ${ids.length} unique IDs, ${refs.size} paths/anchors, disabled form fallback, no template residue.`);
