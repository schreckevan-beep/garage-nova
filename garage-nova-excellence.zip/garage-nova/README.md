# GARAGE NOVA — EXCELLENCE EDITION

Site vitrine automobile de démonstration, en français. Direction artistique anthracite, blanc cassé et orange corail ; photographie automobile, typographie éditoriale et contact direct. Garage Nova est une entreprise fictive : aucune prestation réelle n’est proposée.

Le site livré est autonome en HTML, CSS et JavaScript, sans framework, dépendance à installer, abonnement technique ni serveur applicatif. Les images WebP et les polices WOFF2 sont hébergées avec le site. Node.js sert uniquement à régénérer la page et à la prévisualiser localement.

## Lancer et modifier

Pour une première consultation, ouvrir `index.html` dans un navigateur récent suffit. La copie automatique peut dépendre des permissions du navigateur ; une sélection du texte permet la copie manuelle.

Pour travailler dans les mêmes conditions qu’un hébergement web, depuis ce dossier :

```sh
node tools/serve.mjs
```

Ouvrir [http://127.0.0.1:4173](http://127.0.0.1:4173). Arrêter le serveur avec `Ctrl+C`. Aucun `npm install` n’est nécessaire.

Modifier le contenu dans `content/site.json`, puis régénérer :

```sh
node tools/build.mjs
```

Vérifier ensuite les liens et ressources locales avec `node tools/check.mjs`.

Le générateur combine cette configuration avec `src/index.template.html` et actualise `index.html`, `assets/site-config.js` et `robots.txt`. Actualiser ensuite le navigateur. Modifier directement ces fichiers générés ferait perdre les changements à la prochaine génération.

## Organisation

```text
garage-nova/
├── index.html                 Page statique générée, prête à héberger
├── styles.css                 Mise en page, composants, responsive et animations
├── app.js                     Menu, galerie, fenêtres et préparation du message
├── content/site.json          Identité, couleurs, textes, services, photos, contact
├── src/index.template.html    Structure HTML et libellés d’interface
├── tools/build.mjs            Génération locale sans dépendance
├── tools/serve.mjs            Serveur local de prévisualisation
├── tools/check.mjs            Contrôle des ressources, ancres et fichiers générés
├── assets/
│   ├── brand.svg              Monogramme du garage
│   ├── favicon.svg            Icône du navigateur
│   ├── site-config.js         Configuration publique générée pour les interactions
│   ├── images/                Photos optimisées et CREDITS.txt
│   └── fonts/                 Polices, licences OFL et SOURCES.md
├── robots.txt                 Consignes d’exploration générées
└── .nojekyll                  Publication des fichiers statiques sur GitHub Pages
```

La configuration est publique : ne jamais y placer de mot de passe, de clé privée ou de données personnelles de clients.

## Publier sur GitHub Pages

Cette livraison locale ne signifie pas que le dépôt distant ou le site actuellement en ligne ont été modifiés.

1. Dans une copie du dépôt cible, placer **le contenu de ce dossier à la racine** de la branche choisie : `index.html` doit être directement à cette racine. Conserver `.nojekyll`, les ressources et leurs licences.
2. Vérifier `seo.url` dans `content/site.json`, avec l’URL finale complète et son `/` final. Régénérer la page, puis enregistrer et pousser les changements sur GitHub.
3. Dans le dépôt GitHub : **Settings → Pages → Build and deployment → Source → Deploy from a branch**. Choisir la branche concernée, le dossier **/(root)**, puis **Save**.
4. Contrôler le déploiement dans **Actions**, puis ouvrir l’URL indiquée par GitHub Pages et vérifier les ressources et les interactions.

Les chemins de ressources sont relatifs et conviennent au sous-chemin `/garage-nova/`. Aucun calcul Node.js n’est requis sur l’hébergement : les fichiers générés sont déjà livrés. Ces étapes suivent la [documentation officielle de configuration de GitHub Pages](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site) ; le fichier `.nojekyll` évite le traitement Jekyll pour ce [site statique](https://docs.github.com/en/pages/getting-started-with-github-pages/creating-a-github-pages-site).

## Adapter à un garage réel

- **Identité et univers :** remplacer nom, signature, logo, favicon et couleurs. `brand`, `theme` et les blocs éditoriaux de `content/site.json` rassemblent l’essentiel du contenu.
- **Offre :** relire les services, engagements, questions fréquentes, titres et appels à l’action avec le dirigeant. Toute affirmation doit correspondre à son activité réelle.
- **Coordonnées :** renseigner le téléphone affiché et `phoneHref` au format `tel:+33…`, une adresse email réelle, l’adresse de l’atelier et les horaires. Vérifier les liens d’appel et d’email sur téléphone.
- **Photos :** remplacer les illustrations par des photos autorisées de l’atelier et des réalisations, ou conserver les sources et crédits des photos livrées. Mettre à jour les textes alternatifs, les crédits, les légendes et les mentions « photographie d’illustration » dans la configuration et le modèle si les images deviennent des réalisations réelles.
- **Publication :** remplacer titre, description et URL SEO, puis passer `demo` à `false` **uniquement après** avoir supprimé ou adapté tous les contenus de démonstration. Ce drapeau actualise notamment les consignes d’indexation et le comportement du téléphone ; il ne valide ni les textes ni les coordonnées à votre place.
- **Informations :** compléter les mentions légales et la confidentialité avec les informations authentiques de l’éditeur, de l’hébergeur et des traitements mis en place. Les fenêtres sont personnalisables dans `information` ; modifier aussi `footer.legalStatus` et `footer.privacyStatus` une fois ces contenus prêts.
- **Recette finale :** régénérer, tester contact et navigation au clavier, vérifier plusieurs téléphones et tailles d’écran, puis mesurer Lighthouse sur la version réellement hébergée.

Les licences des polices se trouvent dans `assets/fonts/`. Les sources des photos et leur licence Unsplash sont indiquées dans `assets/images/CREDITS.txt` et dans la fenêtre « Crédits photos ». Vérifier les droits de chaque nouvelle image avant de la publier.

## Fonctions et limites

Le menu mobile, les raccourcis de services vers le formulaire, la galerie agrandie, les questions fréquentes et les fenêtres d’information sont des interactions réelles. Le contenu principal est présent dans le HTML, sans chargement de contenu distant.

Le formulaire **prépare un brouillon** lisible et copiable. Il ne transmet aucune demande à un système de garage, ne réserve aucun créneau et n’annonce jamais un envoi. Le lien `mailto:` propose d’ouvrir une application de messagerie configurée ; l’utilisateur doit encore relire puis envoyer lui-même son email. L’adresse en `.example` est volontairement fictive : aucun message ne peut parvenir à Garage Nova. Le numéro de démonstration ne déclenche pas d’appel.

Le code du site ne stocke pas les saisies et n’intègre aucun outil de mesure d’audience. L’hébergeur et l’application de messagerie peuvent avoir leurs propres traitements. Les blocs légaux livrés sont des emplacements à compléter, pas les documents d’une entreprise réelle.

En mode démonstration, une directive `noindex` et des consignes `robots.txt` découragent l’indexation. Elles ne constituent pas une restriction d’accès : le site publié reste public.

Aucun score Lighthouse n’est garanti ou inventé. Les performances dépendent notamment de l’hébergement, du réseau et de l’appareil ; les mesures et contrôles effectués sont détaillés séparément dans `QA.md`.

## Améliorations par rapport au prototype

| Prototype consulté | Excellence Edition |
| --- | --- |
| Voiture dessinée en SVG dans le hero | Composition photographique, titres affirmés et identité graphique cohérente |
| Quatre services | Cinq services, avec la réparation mécanique et une sélection reportée dans le formulaire |
| Avis fictifs déjà signalés et ancienneté « Depuis 2012 » | Suppression des avis inventés et de l’historique fictif ; confiance construite par la clarté de l’offre |
| Bouton de rendez-vous ouvrant une simple fenêtre explicative | Parcours en trois étapes, formulaire de préparation, copie et ouverture email explicitement décrites |
| Aucun ensemble photographique | Présentation de l’atelier et galerie avec agrandissement, sources et mentions d’illustration |
| Google Fonts appelées à distance | Polices locales, licences jointes et images WebP avec variantes adaptées |
| Contenus dispersés dans le HTML | Configuration éditoriale centrale et génération statique sans dépendance |

Le parti pris reste celui d’un site vitrine de petite entreprise : présenter clairement, rassurer sans inventer de preuves et faciliter un premier échange.
